﻿using DevHabit.Api.Dtos.Common;

namespace DevHabit.Api.Dtos.Users;

public sealed record UserDto
{
    public required string Id { get; set; }
    public required string Name { get; set; }
    public required string Email { get; set; }
    public required DateTime CreatedAtUtc { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }

    public List<LinkDto> Links { get; set; }
}
