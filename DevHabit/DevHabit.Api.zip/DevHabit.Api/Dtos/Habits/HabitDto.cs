﻿#pragma warning disable S6964
using System.ComponentModel.DataAnnotations.Schema;
using DevHabit.Api.Dtos.Common;
using DevHabit.Api.Entities;

namespace DevHabit.Api.Dtos.Habits;

public sealed record HabitDto : ILinksResponse
{
    public required string Id { get; init; }
    public required string Name { get; init; }
    public string? Description { get; init; }
    public required HabitType Type { get; init; }
    public required FrequencyDto Frequency { get; init; }
    public required TargetDto Target { get; init; }
    public required HabitStatus Status { get; init; }
    public required bool IsArchived { get; init; }
    public DateOnly? EndDate { get; init; }
    public int? MilestoneTarget { get; init; }
    public int? MilestoneCurrent { get; init; }
    public required DateTime CreatedAtUtc { get; init; }
    public DateTime? UpdatedAtUtc { get; init; }
    public DateTime? LastCompletedAtUtc { get; init; }
    public List<LinkDto> Links { get; set; }
}

public sealed record FrequencyDto
{
    public FrequencyType Type { get; init; }
    public int TimesPerPeriod { get; init; }
}

public sealed record TargetDto
{
    public required int Value { get; init; }
    public string Unit { get; init; }
}

//public sealed record MilestoneDto
//{
//    public required int Target { get; init; }
//    public required int Current { get; init; }
//}
