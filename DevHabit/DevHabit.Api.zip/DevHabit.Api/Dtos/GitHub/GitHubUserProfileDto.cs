﻿using DevHabit.Api.Dtos.Common;
using Newtonsoft.Json;

namespace DevHabit.Api.Dtos.GitHub;

public sealed record GitHubUserProfileDto(
    [property: JsonProperty("login")] string Login,// for correctly mapping of json props to c# props
    [property: JsonProperty("name")] string? Name,
    [property: JsonProperty("avatar_url")] string AvatarUrl,
    [property: JsonProperty("bio")] string? Bio,
    [property: JsonProperty("public_repos")] int PublicRepos,
    [property: JsonProperty("followers")] int Followers,
    [property: JsonProperty("following")] int Following
) : ILinksResponse
{
    public List<LinkDto> Links { get; set; }
}
